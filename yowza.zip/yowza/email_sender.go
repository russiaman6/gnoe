package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/sha256"
	"encoding/base64"
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"net/smtp"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/joho/godotenv"
)

func decryptMessage(encryptedMessage, encryptionKey string) (string, error) {
	key := sha256.Sum256([]byte(encryptionKey))
	block, err := aes.NewCipher(key[:])
	if err != nil {
		return "", err
	}

	iv := make([]byte, aes.BlockSize)
	ciphertext, _ := base64.StdEncoding.DecodeString(encryptedMessage)
	stream := cipher.NewCFBDecrypter(block, iv)
	plaintext := make([]byte, len(ciphertext))
	stream.XORKeyStream(plaintext, ciphertext)

	return string(plaintext), nil
}

func getEmailList(filePath string) []string {
	content, err := ioutil.ReadFile(filePath)
	if err != nil {
		log.Fatalf("Failed to read email list: %v", err)
	}

	emails := strings.Split(string(content), "\n")
	var result []string
	for _, email := range emails {
		if strings.TrimSpace(email) != "" {
			result = append(result, strings.TrimSpace(email))
		}
	}
	return result
}

func sendEmail(recipientEmail, imageFilePath, fromName, spoofedSenderEmail, subject, link string) {
	logFile, err := os.OpenFile("log.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		log.Fatalf("Failed to open log file: %v", err)
	}
	defer logFile.Close()

	imageData, err := ioutil.ReadFile(imageFilePath)
	if err != nil {
		log.Printf("Failed to read image: %v", err)
		return
	}

	imageCid := fmt.Sprintf("image-%d", time.Now().Unix())
	inlineImage := fmt.Sprintf(`<a href="%s" target="_blank"><img src="cid:%s" alt="Image" style="display:block; max-width:100%%;"></a>`, link, imageCid)

	htmlContent := fmt.Sprintf(`
	<html>
		<body style="margin: 0; padding: 0; background: #f4f4f4;">
			<div style="max-width: 100%%; margin: auto;">
				%s
			</div>
		</body>
	</html>`, inlineImage)

	auth := smtp.PlainAuth("", spoofedSenderEmail, "password", "localhost")
	to := []string{recipientEmail}
	msg := []byte(fmt.Sprintf("To: %s\r\nSubject: %s\r\nMIME-Version: 1.0\r\nContent-Type: text/html\r\n\r\n%s", recipientEmail, subject, htmlContent))

	err = smtp.SendMail("localhost:2525", auth, spoofedSenderEmail, to, msg)
	if err != nil {
		log.Printf("Failed to send email to %s: %v", recipientEmail, err)
		logFile.WriteString(fmt.Sprintf("Failed to send email to %s: %v\n", recipientEmail, err))
	} else {
		log.Printf("Email sent to %s", recipientEmail)
		logFile.WriteString(fmt.Sprintf("Email sent to %s\n", recipientEmail))
	}
}

func main() {
	settings, err := godotenv.Read("settings.ini")
	if err != nil {
		log.Fatalf("Failed to read settings: %v", err)
	}

	emailSubject := settings["EMAIL_SUBJECT"]
	fromName := settings["EMAIL_FROM_NAME"]
	imageFilePath := "tr.png"
	encryptionKey := string(readKeyFile("encryption.key"))
	emailList := getEmailList("email.txt")
	spoofedSenderEmails := getEmailList("mailfrom.txt")
	links := getEmailList("links.txt")

	rand.Seed(time.Now().Unix())

	for _, recipientEmail := range emailList {
		link := links[rand.Intn(len(links))]
		spoofedSenderEmail := spoofedSenderEmails[rand.Intn(len(spoofedSenderEmails))]
		sendEmail(recipientEmail, imageFilePath, fromName, spoofedSenderEmail, emailSubject, link)

		// Sleep to avoid being blocked for too many requests
		time.Sleep(2 * time.Second)
	}
}

func readKeyFile(filePath string) []byte {
	content, err := ioutil.ReadFile(filePath)
	if err != nil {
		log.Fatalf("Failed to read key file: %v", err)
	}
	return content
}
