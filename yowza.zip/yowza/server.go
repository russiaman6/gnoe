package main

import (
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"net"
	"net/mail"
	"net/smtp"
	"os"
	"strings"
	"time"

	"github.com/emersion/go-smtp"
	"github.com/emersion/go-message"
	"github.com/emersion/go-message/mail"
	"github.com/joho/godotenv"
	"golang.org/x/net/proxy"
)

type SMTPConfig struct {
	Host     string `json:"host"`
	Port     int    `json:"port"`
	Username string `json:"username"`
	Password string `json:"password"`
}

type ProxyConfig struct {
	Host     string
	Port     string
	Username string
	Password string
}

func getProxies() ([]ProxyConfig, error) {
	file, err := os.ReadFile("inproxy.ini")
	if err != nil {
		return nil, err
	}

	var proxies []ProxyConfig
	lines := strings.Split(string(file), "\n")
	for _, line := range lines {
		if line == "" {
			continue
		}
		parts := strings.Split(line, ":")
		if len(parts) == 4 {
			proxies = append(proxies, ProxyConfig{
				Host:     parts[0],
				Port:     parts[1],
				Username: parts[2],
				Password: parts[3],
			})
		}
	}
	return proxies, nil
}

func getRandomProxy(proxies []ProxyConfig) ProxyConfig {
	rand.Seed(time.Now().Unix())
	return proxies[rand.Intn(len(proxies))]
}

func getSmtpConfigurations() ([]SMTPConfig, error) {
	file, err := os.ReadFile("smtp.json")
	if err != nil {
		return nil, err
	}

	var smtpConfigs []SMTPConfig
	err = json.Unmarshal(file, &smtpConfigs)
	if err != nil {
		return nil, err
	}

	return smtpConfigs, nil
}

func getLinkFromSettings() string {
	settings, err := godotenv.Read("settings.ini")
	if err != nil {
		log.Printf("Error reading settings.ini: %v", err)
		return "#"
	}
	return settings["EMAIL_LINK"]
}

func getRandomSmtpConfig(smtpConfigs []SMTPConfig) SMTPConfig {
	rand.Seed(time.Now().Unix())
	return smtpConfigs[rand.Intn(len(smtpConfigs))]
}

func forwardEmail(parsedMail *message.Entity, smtpConfig SMTPConfig, proxyConfig ProxyConfig, emailLink string) error {
	dialer, err := proxy.SOCKS5("tcp", fmt.Sprintf("%s:%s", proxyConfig.Host, proxyConfig.Port), &proxy.Auth{
		User:     proxyConfig.Username,
		Password: proxyConfig.Password,
	}, proxy.Direct)
	if err != nil {
		return fmt.Errorf("failed to create proxy dialer: %v", err)
	}

	// Connect to the SMTP server using the proxy dialer
	conn, err := dialer.Dial("tcp", fmt.Sprintf("%s:%d", smtpConfig.Host, smtpConfig.Port))
	if err != nil {
		return fmt.Errorf("failed to connect to SMTP server: %v", err)
	}
	defer conn.Close()

	// Start TLS if required
	tlsConfig := &tls.Config{
		InsecureSkipVerify: true,
		ServerName:         smtpConfig.Host,
	}
	client, err := smtp.NewClient(conn, smtpConfig.Host)
	if err != nil {
		return fmt.Errorf("failed to create SMTP client: %v", err)
	}
	defer client.Quit()

	if err := client.StartTLS(tlsConfig); err != nil {
		return fmt.Errorf("failed to start TLS: %v", err)
	}

	// Authenticate
	auth := smtp.PlainAuth("", smtpConfig.Username, smtpConfig.Password, smtpConfig.Host)
	if err := client.Auth(auth); err != nil {
		return fmt.Errorf("failed to authenticate: %v", err)
	}

	// Extract image attachment
	var imageContent []byte
	imageCID := ""
	mr := mail.NewReader(parsedMail)
	for {
		part, err := mr.NextPart()
		if err == message.ErrEOB {
			break
		} else if err != nil {
			return fmt.Errorf("failed to read part: %v", err)
		}

		switch h := part.Header.(type) {
		case *mail.AttachmentHeader:
			filename, _ := h.Filename()
			if strings.HasPrefix(h.Header.Get("Content-Type"), "image/") {
				imageContent, err = ioutil.ReadAll(part.Body)
				if err != nil {
					return fmt.Errorf("failed to read attachment: %v", err)
				}
				imageCID = h.Header.Get("Content-ID")
				log.Printf("Found image attachment: %s", filename)
			}
		}
	}

	if imageContent == nil {
		return fmt.Errorf("no image attachment found")
	}

	// Prepare the email to forward
	header := mail.Header{}
	header.Set("From", parsedMail.Header.Get("From"))
	header.Set("To", parsedMail.Header.Get("To"))
	header.Set("Subject", parsedMail.Header.Get("Subject"))
	header.Set("MIME-Version", "1.0")
	header.Set("X-Mailer", "Open-Xchange Mailer v7.10.6-Rev59")
	header.Set("X-Originating-IP", fmt.Sprintf("::ffff:%s", proxyConfig.Host))

	mimeBody := message.NewMultipart("related", nil)
	textPart := message.NewPart("text/html", strings.NewReader(fmt.Sprintf(`<html><body><a href="%s" target="_blank"><img src="cid:%s" style="display:block; width:100%%; max-width:1000px; height:auto;" alt="Image"></a></body></html>`, emailLink, imageCID)))
	mimeBody.AddPart(textPart)

	imagePart := message.NewPart("image/jpeg", strings.NewReader(string(imageContent)))
	imagePart.Header.Set("Content-Disposition", "inline; filename=image.jpg")
	imagePart.Header.Set("Content-ID", imageCID)
	mimeBody.AddPart(imagePart)

	if err := client.Mail(parsedMail.Header.Get("From")); err != nil {
		return fmt.Errorf("failed to send MAIL FROM: %v", err)
	}
	if err := client.Rcpt(parsedMail.Header.Get("To")); err != nil {
		return fmt.Errorf("failed to send RCPT TO: %v", err)
	}

	writer, err := client.Data()
	if err != nil {
		return fmt.Errorf("failed to send DATA: %v", err)
	}

	mimeBody.WriteTo(writer)
	writer.Close()

	log.Printf("Email forwarded successfully using SMTP server: %s:%d", smtpConfig.Host, smtpConfig.Port)
	return nil
}

func main() {
	proxies, err := getProxies()
	if err != nil {
		log.Fatalf("Failed to read proxies: %v", err)
	}

	smtpConfigs, err := getSmtpConfigurations()
	if err != nil {
		log.Fatalf("Failed to read SMTP configurations: %v", err)
	}

	emailLink := getLinkFromSettings()

	server := smtp.NewServer(&smtp.Backend{
		Func: func(state *smtp.State, from, to string, r *smtp.MailReader) error {
			log.Printf("Received email from %s to %s", from, to)
			entity, err := message.Read(r)
			if err != nil {
				return fmt.Errorf("failed to parse email: %v", err)
			}

			proxyConfig := getRandomProxy(proxies)
			smtpConfig := getRandomSmtpConfig(smtpConfigs)

			return forwardEmail(entity, smtpConfig, proxyConfig, emailLink)
		},
	})

	server.Addr = "127.0.0.1:2525"
	server.Domain = "localhost"
	server.AllowInsecureAuth = true

	log.Println("SMTP relay server listening on port 2525")
	if err := server.ListenAndServe(); err != nil {
		log.Fatalf("Failed to start SMTP server: %v", err)
	}
}
